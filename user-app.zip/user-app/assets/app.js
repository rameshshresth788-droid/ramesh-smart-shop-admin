const API_URL = '../api/get_products.php';
let products = [];
let activeCategory = 'All';
const grid = document.getElementById('productGrid');
const statusEl = document.getElementById('status');
const countEl = document.getElementById('productCount');
const searchInput = document.getElementById('searchInput');
const clearSearch = document.getElementById('clearSearch');
const chips = document.getElementById('categoryChips');
const refreshBtn = document.getElementById('refreshBtn');

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function price(value) {
  return '₹' + Number(value || 0).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
}
function renderChips() {
  const cats = ['All', ...new Set(products.map(p => p.category).filter(Boolean))];
  chips.innerHTML = cats.map(c => `<button class="chip ${c===activeCategory?'active':''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
  chips.querySelectorAll('.chip').forEach(btn => btn.addEventListener('click', () => {
    activeCategory = btn.dataset.cat;
    chips.querySelectorAll('.chip').forEach(x => x.classList.toggle('active', x === btn));
    renderProducts();
  }));
}
function renderProducts() {
  const q = searchInput.value.trim().toLowerCase();
  const filtered = products.filter(p => {
    const text = `${p.name} ${p.category}`.toLowerCase();
    return (!q || text.includes(q)) && (activeCategory === 'All' || p.category === activeCategory);
  });
  countEl.textContent = `${filtered.length} product${filtered.length === 1 ? '' : 's'}`;
  if (!filtered.length) {
    grid.innerHTML = `<div class="empty"><div>⌕</div><strong>No products found</strong><span>Try another search or category.</span></div>`;
    return;
  }
  grid.innerHTML = filtered.map((p, i) => `
    <article class="product-card" style="--delay:${Math.min(i,8)*.04}s">
      <div class="photo">${p.image_url ? `<img src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}" loading="lazy">` : '<span>No image</span>'}</div>
      <div class="product-body">
        <span class="category">${escapeHtml(p.category)}</span>
        <h3>${escapeHtml(p.name)}</h3>
        <div class="price">${price(p.price)}</div>
        <div class="updated">Updated ${formatDate(p.updated_at || p.created_at)}</div>
      </div>
    </article>`).join('');
}
function formatDate(value) {
  if (!value) return 'recently';
  const d = new Date(value.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return 'recently';
  return d.toLocaleDateString('en-IN', {day:'2-digit', month:'short', year:'numeric'});
}
async function loadProducts() {
  statusEl.textContent = 'Loading products...';
  statusEl.classList.remove('hidden','error');
  refreshBtn.classList.add('spin');
  try {
    const res = await fetch(`${API_URL}?_=${Date.now()}`, {cache:'no-store'});
    const data = await res.json();
    if (!res.ok || !data.success) throw new Error(data.message || 'Unable to load products');
    products = data.data?.products || [];
    activeCategory = 'All';
    renderChips();
    renderProducts();
    statusEl.classList.add('hidden');
  } catch (e) {
    products = [];
    countEl.textContent = '0 products';
    grid.innerHTML = '';
    statusEl.textContent = 'Products could not be loaded. Please try again.';
    statusEl.classList.add('error');
  } finally { refreshBtn.classList.remove('spin'); }
}
searchInput.addEventListener('input', () => { clearSearch.hidden = !searchInput.value; renderProducts(); });
clearSearch.addEventListener('click', () => { searchInput.value=''; clearSearch.hidden=true; searchInput.focus(); renderProducts(); });
refreshBtn.addEventListener('click', loadProducts);
loadProducts();
